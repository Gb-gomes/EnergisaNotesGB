-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: energisanotes
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `incidentes`
--

DROP TABLE IF EXISTS `incidentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incidentes` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Titulo` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `TextoTemplate` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `CategoriaId` int NOT NULL,
  `UltimoEditorId` int DEFAULT NULL,
  `DataCriacao` datetime(6) NOT NULL,
  `DataAtualizacao` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `IX_Incidentes_CategoriaId` (`CategoriaId`),
  KEY `IX_Incidentes_UltimoEditorId` (`UltimoEditorId`),
  CONSTRAINT `FK_Incidentes_Categorias_CategoriaId` FOREIGN KEY (`CategoriaId`) REFERENCES `categorias` (`Id`) ON DELETE RESTRICT,
  CONSTRAINT `FK_Incidentes_Usuarios_UltimoEditorId` FOREIGN KEY (`UltimoEditorId`) REFERENCES `usuarios` (`Id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidentes`
--

LOCK TABLES `incidentes` WRITE;
/*!40000 ALTER TABLE `incidentes` DISABLE KEYS */;
INSERT INTO `incidentes` VALUES (1,'Acidente construção civil​','A Energisa lamenta o acidente com o trabalhador, ocorrido na tarde desta XXX (XX), no município de XXX. A concessionária enviou imediatamente equipes para o local, a fim de dar suporte ao Corpo de Bombeiros durante o trabalho de resgate. ​\n\n​\n\nA empresa reforça o alerta à comunidade sobre os riscos de realizar trabalhos próximos à rede elétrica. Além de montar andaimes a uma distância segura dos fios e não manusear calhas, extensores e outras ferramentas perto da rede elétrica, a empresa enfatiza a importância do uso de equipamentos de proteção individual. ​\n\n​\n\nEm caso de acidente envolvendo a rede elétrica, entre em contato com a concessionária pelos canais de atendimento: aplicativo Energisa On ou 0800-XXX-XXXX. ​',1,1,'2025-12-09 22:51:11.000000',NULL),(2,'Por poda de árvore​','A Energisa informa que técnicos estiveram no local para dar apoio ao Corpo de Bombeiros. A empresa orienta os moradores que informem por meio de seus canais de atendimento sempre que identificarem galhos de árvores encostando na rede elétrica. Os pontos serão incluídos no cronograma de manutenção para que a Energisa faça a remoção desses galhos em parceria com órgãos municipais. É importante que somente profissionais capacitados e usando materiais de proteção individual realizem esse tipo de atividade, devido ao risco de choque elétrico. O contato deve ser feito pelo 0800-XXX-XXXX, informando o número da unidade consumidora. ​\n\n ​\n\nA empresa ainda orienta a: ​\n\n ​\n\n- Nunca realizar poda de árvores que estejam em contato com a rede elétrica; ​\n\n- Não escalar árvore que esteja próxima à rede ou que esteja dando indícios de contato com energia; ​\n\n- Não permita que pessoas não autorizadas se aproximem;​\n\n- Não colha frutos em árvores próximas à rede elétrica. ​',1,1,'2025-12-09 22:46:18.000000',NULL),(3,'Construção em local irregular (debaixo da rede)','A empresa lamenta o ocorrido e ressalta a importância de ser comunicada em caso de construção de imóveis próximos à rede elétrica para garantir a segurança e evitar acidentes.​\n\n​\n\nA rede elétrica representa risco e apenas profissionais qualificados e com equipamentos de segurança adequados podem atuar nas proximidades das instalações. ​\n\n​\n\n(Abordar caso a Energisa trabalha em parceria com prefeitura para a adequação de ocupações irregulares)​',1,1,'2025-12-09 22:49:19.000000',NULL),(4,'Invasão SE sem morte​','Na noite desta XXX (XX), uma pessoa acessou irregularmente a subestação XXX, em XXX. Por questões de segurança, a energia precisou ser interrompida por volta das XXh, sendo restabelecida às XXh. O caso segue em investigação pelas autoridades competentes. ​\n\n​\n\nA Energisa reforça sua política de valorização da vida e segurança de colaboradores e comunidade. Na subestação e no entorno, há avisos sobre o risco de acessar fios e equipamentos de alta tensão. ​',1,1,'2025-12-09 22:50:32.000000',NULL),(5,'Invasão SE com morte','A empresa lamenta a morte de um homem ainda não identificado nas instalações de uma subestação na noite desta XXX (XX), por volta das xxh. Com o acesso irregular à subestação, foi necessário desligar o sistema que abastece o município de XXX, afetando XXX clientes. Equipes da empresa estão no local, aguardando a perícia policial para restabelecer o serviço.  ​\n\n​\n\nA Energisa alerta para o risco de se mexer na rede elétrica e pede que atitudes suspeitas em suas unidades ou na receptação de materiais elétricos de origem duvidosa sejam denunciadas às autoridades. ​',1,1,'2025-12-09 22:52:20.000000',NULL),(6,'Morte após encostar em cabo​','A Energisa informa que está apurando as circunstâncias do acidente que ocasionou a morte de um homem no dia xxx. A empresa lamenta profundamente o ocorrido e lembra que a comunidade deve evitar qualquer contato com a rede elétrica e informar a concessionária sempre que for realizar qualquer tipo de intervenção.',1,1,'2025-12-09 23:07:08.000000','2025-12-09 23:07:08.000000'),(7,'Morte de animal após encostar em cabo ​','A Energisa lamenta o ocorrido e informa que está investigando a causa do rompimento do cabo. A suspeita é que tenha sido por descarga atmosférica devido ao temporal que atingiu a região. ​\n\n​\n\nA Companhia reforça o seu compromisso com a biodiversidade da região e destaca sua atuação para a preservação do bioma.​\n\n​',1,1,'2025-12-10 20:57:53.000000','2025-12-10 20:57:53.000000'),(8,'Morte de terceiro por autorreligação​​','A Energisa lamenta o acidente que ocorreu esta manhã,  resultando na morte de um homem no bairro Jardim Santana, em Porto Velho. No local do acidente , foi constatada uma tentativa de ligação clandestina de energia . A empresa mais uma vez reforça que o furto de energia é crime previsto em lei. As ligações clandestinas colocam  em risco a segurança da população, provocando acidentes graves e até mesmo fatais.  A empresa também alerta que somente profissionais da Energisa, que possuem treinamento  e utilizam os equipamentos de proteção individuais e coletivos adequados, podem interferir na rede elétrica.​',1,1,'2025-12-10 20:58:47.000000','2025-12-10 20:58:47.000000'),(9,'Acidente em torre de transmissão sem morte​','A Energisa confirma a ocorrência de um acidente na obra de construção da linha de transmissão localizada em XXX, que vai interligar as subestações [nomes das subestações], na região XXX. Por meio da empresa terceirizada, está sendo prestada toda assistência aos trabalhadores juntamente com o Corpo de Bombeiros. As causas desse incidente estão sendo analisadas.​',2,1,'2025-12-10 21:58:22.000000','2025-12-10 21:58:22.000000'),(10,'Acidente em torre de transmissão sem morte​','A Energisa confirma a ocorrência de um acidente na obra de construção da linha de transmissão localizada em XXX, que vai interligar as subestações [nomes das subestações], na região XXX. Por meio da empresa terceirizada, está sendo prestada toda assistência aos trabalhadores juntamente com o Corpo de Bombeiros. As causas desse incidente estão sendo analisadas.​',2,1,'2025-12-11 21:25:11.000000','2025-12-11 21:25:11.000000');
/*!40000 ALTER TABLE `incidentes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-15 21:38:42
